package blue.gis.thisoldhouse;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = (TextView) this.findViewById(R.id.text_view_title);

        textView.setText(R.string.products_title);


        final ArrayList<String> candy_list = new ArrayList<String>();


        candy_list.add("pressure wash");
        candy_list.add("kitchen floor");
        candy_list.add("remove wallpaper");
        candy_list.add("paint bedroom");
        candy_list.add("pull up patio blocks");
        candy_list.add("new appliances");
        candy_list.add("replace rotten wood");
        candy_list.add("reglaze windows");

        //candy_list.add("");
        //candy_list.add("");
        //candy_list.add("");
        //candy_list.add("");
        //candy_list.add("");
        //candy_list.add("");


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                R.layout.list_item_candy,
                R.id.text_view_candy,
                candy_list);

        ListView listView = (ListView) this.findViewById(R.id.list_view_candy);

        listView.setAdapter(adapter);

        Context context = this;
        String text = "Hello toast";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(
                    AdapterView<?> adapterView, View view, int i, long l) {
                //Toast toast = Toast.makeText(MainActivity.this, "" + i, Toast.LENGTH_SHORT);
                //toast.show();

                Intent detailIntent = new Intent(MainActivity.this,
                        DetailActivity.class);
                detailIntent.putExtra("candy_name", candy_list.get(i));
                startActivity(detailIntent);



            }

            //listView.setOnItemClickListener(adapterView); view, i, l);
            //Toast newToast = Toast.makeText(MainActivity.this, ""+i, Toast.LENGTH_SHORT);
            //newToast.show();


        });
    }
}
